<template>
  <div>
    <p>table1Edit.vue</p>
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style scoped>

</style>