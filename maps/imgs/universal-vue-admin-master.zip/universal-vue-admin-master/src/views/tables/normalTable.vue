<template>
  <div>
    <p>normalTable.vue</p>
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style scoped>

</style>