"use strict";
module.exports = {
  NODE_ENV: '"production"',
  BASE_URL: '"https://www.easy-mock.com/mock/5b6142e7cbc4e209c427f9f4/api_v1"'
};
