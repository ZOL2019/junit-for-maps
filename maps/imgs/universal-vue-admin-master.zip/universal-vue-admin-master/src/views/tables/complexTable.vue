<template>
  <div>
    <p>complexTable.vue</p>
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style scoped>

</style>