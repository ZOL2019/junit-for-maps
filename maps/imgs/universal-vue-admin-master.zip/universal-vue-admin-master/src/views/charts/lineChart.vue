<template>
  <div>
    <p>lineChart</p>
  </div>
</template>

<script>
  export default {};
</script>

<style scoped>
  
</style>