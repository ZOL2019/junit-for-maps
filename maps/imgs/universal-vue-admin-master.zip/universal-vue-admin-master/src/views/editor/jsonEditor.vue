<template>
  <div>
    <p>jsonEditor.vue</p>
  </div>
</template>

<script>
  export default {
  
  }
</script>

<style scoped>
  
</style>