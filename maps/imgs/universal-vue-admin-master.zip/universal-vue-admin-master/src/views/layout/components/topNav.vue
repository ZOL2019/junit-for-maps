<template>
  <div class="top-nav-container">
    header
  </div>
</template>

<script>
export default {};
</script>

<style scoped lang="scss">
.top-nav-container {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: 50px;
  border-bottom: 1px solid #e6e6e6;
  box-sizing: border-box;
}
</style>